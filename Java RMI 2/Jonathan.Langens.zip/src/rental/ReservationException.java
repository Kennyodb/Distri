package rental;

public class ReservationException extends Exception {

	private static final long serialVersionUID = -8159128964694199920L;

	public ReservationException(String string) {
        super(string);
    }
}
